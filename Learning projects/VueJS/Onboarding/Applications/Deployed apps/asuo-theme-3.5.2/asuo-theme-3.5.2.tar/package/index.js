import ASUOTheme from "./style/asuo-theme.scss";

export default ASUOTheme;
